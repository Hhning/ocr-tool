# -*- coding:utf-8 -*-

from __future__ import absolute_import, print_function

from sigma_sdk.api import OCRAPI, AutoRunAPI

# Optical Character Recognition
ocr_api_obj = OCRAPI(endpoint="http://127.0.0.1:7002")
ocr_response = ocr_api_obj.recognition("C:\\12sigma\\engine\\sigmaOCR\\image2string_exec\\test_image.png")
print(ocr_response.img_file)
print(ocr_response.optical_character_value)

# series status auto run status
auto_run_api_obj = AutoRunAPI(endpoint="http://127.0.0.1:7002")
auto_run_response = auto_run_api_obj.get_status(patient_id="111644939")
print(auto_run_response.patient_id)
print(auto_run_response.study_id)
print(auto_run_response.series_id)
print(auto_run_response.status)

# get data status
# data_api_obj = DataAPI(sigma_auth_obj, "http://127.0.0.1:7070")
# data_info = data_api_obj.get_data_status(unique_id="user-005-data-0", formats="json", category="original")
# print(data_info.patient_id)
# print(data_info.study_id)
# print(data_info.series_id)
# print(data_info.status)
#
# # new a job
# job_api_obj = JobAPI(sigma_auth_obj, "http://127.0.0.1:7070")
# job_info = job_api_obj.new_job(job_type="lung_nodule_det", file_format="dicom", unique_id="1.2.840.113619.2.327.3.2831163140.116.1512690967.656.3.31.25000051251220171208", level="series")
# print(job_info.job_id)
# print(job_info.patient_id)
# print(job_info.status)
#
# # get job status list
# job_list = job_api_obj.list_jobs(unique_id="1.2.840.113619.2.327.3.2831163140.116.1512690967.656.3.31.25000051251220171208")
# for job in job_list:
#     print(job.job_id)
#     print(job.patient_id)
#     print(job.status)
