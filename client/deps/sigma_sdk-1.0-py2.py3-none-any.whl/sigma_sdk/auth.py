# -*- coding=utf-8 -*-

from __future__ import absolute_import, print_function

import logging
import time
import hashlib
import hmac
import base64
import requests

try:
    from urlparse import urlsplit
except ImportError as e:
    from urllib.parse import urlsplit

SELF_DEFINE_HEADER_PREFIX = "x-sigma-"
SELF_DEFINE_AUTH_PREFIX = "12Sigma"


def convert_utf8(input_string):
    if isinstance(input_string, unicode):
        input_string = input_string.encode('utf-8')
    return input_string


def extract_resource_from_url(url):
    if url.lower().startswith("http://"):
        idx = url.find('/', 7, -1)
        return url[idx:].strip()
    elif url.lower().startswith("https://"):
        idx = url.find('/', 8, -1)
        return url[idx:].strip()
    else:
        return url.strip()


def format_header(headers=None):
    """
    format the headers that self define
    convert the self define headers to lower.
    """
    if not headers:
        headers = {}
    tmp_headers = {}

    for k in headers.keys():
        tmp_str = headers[k]
        if isinstance(tmp_str, unicode):
            tmp_str = convert_utf8(tmp_str)

        if k.lower().startswith(SELF_DEFINE_HEADER_PREFIX):
            k_lower = k.lower().strip()
            tmp_headers[k_lower] = tmp_str
        else:
            tmp_headers[k.strip()] = tmp_str
    return tmp_headers


def canonicalize_resource(resource):
    res_list = resource.split("?")
    if len(res_list) <= 1 or len(res_list) > 2:
        return resource
    res = res_list[0]
    param = res_list[1]
    params = param.split("&")
    params = sorted(params)
    param = '&'.join(params)
    return res + '?' + param


def get_canonicalized_headers(headers):
    """Get canonicalized headers.

    :arg dict headers: http headers
    :return string canonicalized: the string of canonicalized headers
    """
    if not headers:
        headers = dict()
    canonicalized = []
    keys = sorted(headers.keys())
    for key in keys:
        if key.startswith(SELF_DEFINE_HEADER_PREFIX):
            canonicalized.append("%s:%s" % (key, headers[key].strip()))
    return "\n".join(canonicalized)


def get_canonicalized_resource(url):
    """Get parameters from URL and sort them.

    :arg str url: uri link
    :return str url: return url after sorted of query parameters
    """
    # Split url, get tuples
    parsed = urlsplit(url)
    # This url not include query conditions
    if not parsed.query:
        return url[(len(parsed.scheme) + 3):].strip()
    # Sort query conditions
    query = "&".join(sorted(parsed.query.split("&")))
    # Build new url
    canonicalized = (parsed.netloc + parsed.path + "?" + query)
    return canonicalized


def convert_to_utf8(content):
    """Convert input string to utf-8 stype.

    :arg str content: string content
    :return str content: string content
    """
    if isinstance(content, unicode):
        return content.encode("utf-8")
    else:
        return content


def format_http_headers(headers=None):
    """Format http headers, convert user-defined headers.

    :arg dict headers: http headers
    :return dict headers: sort and lower of http header content
    """
    if headers is None:
        headers = dict()
    parsed = dict()

    for key in headers.keys():
        content = convert_to_utf8(headers[key])
        if key.lower().startswith(SELF_DEFINE_HEADER_PREFIX):
            parsed[key.lower().strip()] = content
        else:
            parsed[key.strip()] = content
    return parsed


def base64_encode(digest):
    """Encode string use base64.

    :arg string digest: encode content
    :return string encoded
    """
    return base64.b64encode(digest).strip()


class SigmaAuth(requests.auth.AuthBase):
    def __init__(self, access_key_id, access_key_secret, verbose=True):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.verbose = verbose
        if verbose:
            self.logger = logging.getLogger("auth")
            self.logger.debug("Initialize SigmaAuth, access key id: " + access_key_id +
                              ", access key secret: " + access_key_secret)

    def __call__(self, r):
        # Format http, convert prefix is x-sigma- to lower
        headers = format_http_headers(r.headers)
        # Get content-type and content-md5
        content_type = headers.get("Content-Type", "")
        content_md5 = headers.get("Content-Md5", "")
        # Get date from headers, date is GMT time
        date = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime())

        # Get canonicalized headers
        canonicalized_headers = get_canonicalized_headers(headers)
        # Get canonicalized resource
        canonicalized_resource = get_canonicalized_resource(r.url)
        canonicalized = ""
        if canonicalized_headers:
            canonicalized += (canonicalized_headers + "\n" + canonicalized_resource)
        else:
            canonicalized += canonicalized_resource
        # Build canonicalized, if canonicalized_headers is empty, igore it
        sign = "\n".join([r.method,
                          content_md5,
                          content_type,
                          date,
                          canonicalized])
        signature = base64_encode(hmac.new(str(self.access_key_secret), sign, hashlib.sha256).digest())

        r.headers["Date"] = date
        r.headers["Authorization"] = SELF_DEFINE_AUTH_PREFIX + " " + self.access_key_id + ":" + signature
        if self.verbose:
            self.logger.info("Authorization header: " + r.headers["Authorization"])

        return r
