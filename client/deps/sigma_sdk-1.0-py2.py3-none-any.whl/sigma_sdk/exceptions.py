# -*- coding=utf-8 -*-

from __future__ import absolute_import, print_function

import requests


class SGAPIBaseException(Exception):
    """
        Exception for when the API server responds with a code that is not 200 (OK).
    """

    def __init__(self, content, code):
        self.error_code = content.get("error", {}).get("code", "")
        self.msg = content.get("error", {}).get("message", "") or content.get("msg",
                                                                              "Can not find any error information!")
        self.msg_chs = content.get("error", {}).get("message_chs", "") or content.get("msg_chs", "未找到相应错误信息！")
        self.request_error_code = code

    def __str__(self):
        output = self.msg + "\n" + self.msg_chs + "\n" + " code " + str(self.request_error_code)
        if self.error_code != self.__class__.__name__:
            output = self.error_code + ": " + output
        return output


class MalformedJSON(SGAPIBaseException):
    """ Raised when the input could not be parsed as JSON. """
    pass


class InvalidAuthentication(SGAPIBaseException):
    """ Raised when the provided Auth token is invalid. """
    pass


class PermissionDenied(SGAPIBaseException):
    """ Raised when the supplied credentials have insufficient permissions to perform this action. """
    pass


class ResourceNotFound(SGAPIBaseException):
    """ Raised when a specified entity or resource could not be found. """
    pass


class InvalidInput(SGAPIBaseException):
    """ Raised when the input is syntactically correct (JSON), but semantically incorrect (for example, a JSON array
    is provided where a hash was required; or a required parameter was missing, etc.). """
    pass


class FormatError(SGAPIBaseException):
    """ Raised when format of input parameters is invalid. """
    pass


class InvalidIndex(SGAPIBaseException):
    """ Raised when index of input parameters is invalid. """
    pass


class ContentLengthError(requests.HTTPError):
    """ Will be raised when actual content length received from server does not match the "Content-Length" header. """
    pass


class InnerServiceError(SGAPIBaseException):
    """ Will be raised when got internal server error. """
    pass


class ResourceAlreadyExists(SGAPIBaseException):
    """ Will be raised when resource already exists. """
    pass


class UnsupportedOperation(SGAPIBaseException):
    """ Will be raised when there is no supported operation. """
    pass


class NewJobFailed(SGAPIBaseException):
    "Will be raised when new job failed"
    pass


network_exceptions = (requests.ConnectionError,
                      requests.exceptions.ChunkedEncodingError,
                      requests.exceptions.ContentDecodingError,
                      requests.HTTPError,
                      requests.Timeout,
                      requests.packages.urllib3.connectionpool.HTTPException)
