# -*- coding=utf-8 -*-

from __future__ import absolute_import, print_function

import json

from sigma_sdk import exceptions, logger
from sigma_sdk.http import HTTPRequest
from sigma_sdk.models import JobInfo, AutoRunBaseInfo, DataInfo, DataStatus, OCRBaseInfo


class DataAPI(object):
    def __init__(self, auth, endpoint):
        self.auth = auth
        self.endpoint = endpoint

    def get_data_status(self, unique_id, formats, category, **kwargs):
        logger.info(
            "begin get data status, unique id {}, formats {}, category {},  kwargs {}".format(unique_id, formats,
                                                                                              category, kwargs))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/data/meta/{}?format={}&category={}".format(unique_id, formats, category)
        try:
            response = HTTPRequest(resource=resource, data=None, headers=headers, api_server=self.endpoint, method="GET", auth=self.auth)
            response_list_length = len(response)
            data_info = DataInfo()
            if response_list_length == 0:
                data_info.patient_id = kwargs.get("patient_id")
                data_info.study_id = kwargs.get("study_id")
                data_info.series_id = kwargs.get("series_id")
                data_info.status = DataStatus.UNAVAILABLE
            else:
                file_number = response[0]["count"]
                if response_list_length != file_number:
                    data_info.patient_id = kwargs.get("patient_id")
                    data_info.study_id = kwargs.get("study_id")
                    data_info.series_id = kwargs.get("series_id")
                    data_info.status = DataStatus.UNAVAILABLE
                else:
                    data_info.patient_id = kwargs.get("patient_id")
                    data_info.study_id = kwargs.get("study_id")
                    data_info.series_id = kwargs.get("series_id")
                    data_info.status = DataStatus.NORMAL
            logger.info("get data status successfully!")
            return data_info
        except exceptions.SGAPIBaseException as e:
            logger.warning("get data status failed, becuase {}".format(e))
            raise


class JobAPI(object):
    def __init__(self, auth, endpoint):
        self.auth = auth
        self.endpoint = endpoint

    def new_job(self, job_type, file_format, **kwargs):
        logger.info("begin new job, job type {}, file format {}, kwargs {}".format(job_type, file_format, kwargs))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/jobs"
        request_data = {"type": job_type, "format": file_format, "unique_id": kwargs["unique_id"],
                        "ae_title": kwargs.get("ae_title"), "level": kwargs.get("level"),
                        "patient_id": kwargs.get("patient_id"), "study_id": kwargs.get("study_id"),
                        "series_id": kwargs.get("series_id"), "priority": kwargs.get("priority")}

        print(request_data)
        try:
            response = HTTPRequest(resource=resource, data=request_data, headers=headers, api_server=self.endpoint, auth=self.auth)
            job_info = JobInfo(response["job_id"], response.get("patient_id"), status=response.get("status"))
            logger.info("new job successfully!")
            return job_info
        except exceptions.SGAPIBaseException as e:
            logger.warning("new job failed, because {}".format(e))
            raise

    def get_job(self, job_id=None, **kwargs):
        logger.info("begin get job, job id {}, kwargs {}".format(job_id, kwargs))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/jobs?job_id={}".format(job_id)
        try:
            response = HTTPRequest(resource=resource, data=None, headers=headers, api_server=self.endpoint, method="GET", auth=self.auth)
            job_info = JobInfo(response["job_id"], response.get("patient_id"), status=response.get("status"))
            logger.info("get job successfully!")
            return job_info
        except exceptions.SGAPIBaseException as e:
            logger.warning("get job failed, becuase {}".format(e))
            raise

    def list_jobs(self, filters=None, page=None, size=None, **kwargs):
        logger.info("begin list jobs, filters {}, page {}, size {}, kwargs {}".format(filters, page, size, kwargs))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/jobs?unique_id={}".format(kwargs.get("unique_id"))
        try:
            response = HTTPRequest(resource=resource, data=None, headers=headers, api_server=self.endpoint, method="GET",
                                   auth=self.auth)
            job_list = list()
            for job in response:
                job_info = JobInfo(job_id=job["job_id"], patient_id=job.get("patient_id"), status=job.get("status"))
                job_list.append(job_info)
            logger.info("list jobs successfully!")
            return job_list
        except exceptions.SGAPIBaseException as e:
            logger.warning("list jobs failed, because {}".format(e))
            raise

    def delete_job(self, job_id=None, **kwargs):
        logger.info("begin delete job, job id {}, kwargs {}".format(job_id, kwargs))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/jobs?job_id={}".format(job_id)
        try:
            response = HTTPRequest(resource=resource, data=None, headers=headers, api_server=self.endpoint, method="DELETE",
                                   auth=self.auth)
            logger.info("delete job {} successfully!".format(job_id))
        except exceptions.SGAPIBaseException as e:
            logger.warning("delete job failed, because {}".format(e))
            raise


class AutoRunAPI(object):
    def __init__(self, auth=None, endpoint=None):
        self.auth = auth
        if endpoint is None:
            self.endpoint = "http://127.0.0.1:7070"
        else:
            self.endpoint = endpoint

    def get_status(self, patient_id=None, study_id=None, series_id=None, accession_number=None, status=None):
        logger.info(
            "begin get auto run job status, patient id {}, study id {}, series id {}".format(patient_id, study_id,
                                                                                             series_id))
        headers = {
            "Content-Type": "application/json"
        }
        resource = "/autorun/series?patient_id={}&study_instance_uid={}&series_instance_uid={}&accession_number={}&status={}".format(patient_id, study_id, series_id, accession_number, status)
        try:
            response = HTTPRequest(resource=resource, data=None, headers=headers, api_server=self.endpoint, method="GET", auth=self.auth)
            response = json.loads(response)
            if response["data"]:
                auto_run_base_info = AutoRunBaseInfo(patient_id=response["data"].get("patient_id"), study_id=response["data"].get("study_instance_uid"), series_id=response["data"].get("series_instance_uid"),
                                                     accession_number=response["data"].get("accession_number"), status=response["data"]["status"])
            else:
                auto_run_base_info = AutoRunBaseInfo(patient_id=patient_id, study_id=study_id, series_id=series_id)
            logger.info("get auto run job status successfully!")
            return auto_run_base_info
        except exceptions.SGAPIBaseException as e:
            logger.warning("get auto run job status failed, becuase {}".format(e))
            raise


class OCRAPI(object):
    def __init__(self, auth=None, endpoint=None):
        self.auth = auth
        if endpoint is None:
            self.endpoint = "http://127.0.0.1:7070"
        else:
            self.endpoint = endpoint

    def recognition(self, img_path):
        logger.info("begin sent the image to server and recognition the optical character!")
        resource = "/ocr/"
        files = {"file": open(img_path, "rb")}
        try:
            response = HTTPRequest(resource=resource, data=None, jsonify_data=False, api_server=self.endpoint, method="POST", files=files)
            response = json.loads(response)
            ocr_base_info_obj = OCRBaseInfo(img_path, response["data"])
            logger.info("recognition the optical character successfully!")
            return ocr_base_info_obj
        except exceptions.SGAPIBaseException as e:
            logger.warning("recognition the optical character failed, because {}".format(e))
            raise
