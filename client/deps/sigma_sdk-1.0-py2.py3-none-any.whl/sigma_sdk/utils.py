# -*- coding=utf-8 -*-

import hashlib
import io


def get_md5_hexdigest(content, is_file=False):
    """Calculate md5 hexdigest of content.
    :arg string content: Input str or bytes
    :arg boolean is_file: whether the content is a file path
    :return string checksum or error
    """
    # If content is None, write a byte char
    if content is None:
        content = b""
    checksum = ""
    # If set is_file=True, read file
    if is_file:
        value = hashlib.md5()
        data = io.FileIO(content, "r")
        blocksize = 1024 * 8
        byte = data.read(blocksize)
        while byte != b"":
            value.update(byte)
            byte = data.read(blocksize)
        data.close()
        checksum = value.hexdigest()
    else:
        checksum = hashlib.md5(content).hexdigest()
    # If checksum is bytes, decode to utf-8 chars
    if isinstance(checksum, bytes):
        checksum = checksum.decode("utf-8")
    return checksum
