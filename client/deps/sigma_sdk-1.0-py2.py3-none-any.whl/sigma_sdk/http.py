# -*- coding=utf-8 -*-

from __future__ import absolute_import, print_function

import collections
import errno
import json
import os
import socket
import sys
import time
import traceback

import requests
from requests.exceptions import ConnectionError, HTTPError

from sigma_sdk import exceptions, logger


default_encoding = "utf-8"
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)

DEFAULT_RETRIES = 3

snappy_available = True
if sys.version_info < (3, 0):
    try:
        import snappy

    except ImportError:
        snappy_available = False
else:
    snappy_available = False

SESSION_HANDLERS = collections.defaultdict(requests.session)

_expected_exceptions = exceptions.network_exceptions


def _process_method_url_headers(method, url, headers):
    if callable(url):
        _url, _headers = url()
        _headers.update(headers)
    else:
        _url, _headers = url, headers
    # When *data* is bytes but *headers* contains Unicode text, httplib tries to concatenate them and decode
    # *data*, which should not be done. Also, per HTTP/1.1 headers must be encoded with MIME, but we'll
    # disregard that here, and just encode them with the Python default (ascii) and fail for any non-ascii
    # content. See http://tools.ietf.org/html/rfc3987 for a discussion of encoding URLs.
    # TODO: ascertain whether this is a problem in Python 3/make test
    # TODO: when the python version is not 2.*
    return method.encode(), _url.encode('utf-8'), {k.encode(): v.encode() for k, v in _headers.items()}


# When any of the following errors are indicated, we are sure that the
# server never received our request and therefore the request can be
# retried (even if the request is not idempotent).
_RETRYABLE_SOCKET_ERRORS = {
    errno.ENETDOWN,  # The network was down
    errno.ENETUNREACH,  # The subnet containing the remote host was unreachable
    errno.ECONNREFUSED  # A remote host refused to allow the network connection
}


def _is_retryable_exception(e):
    """Returns True if the exception is always safe to retry.
    This is True if the client was never able to establish a connection
    to the server (for example, name resolution failed or the connection
    could otherwise not be initialized).
    Conservatively, if we can't tell whether a network connection could
    have been established, we return False.
    """
    try:
        if isinstance(e, ConnectionError):
            # Unfortunately requests doesn't seem to provide a sensible
            # API to retrieve the cause
            cause = e.args[0].args[1]
            if isinstance(cause, (socket.gaierror, socket.herror)):
                return True
            if isinstance(cause, socket.error) and cause.errno in _RETRYABLE_SOCKET_ERRORS:
                return True
        return False

    except (AttributeError, TypeError, IndexError):
        return False


def HTTPRequest(resource, data, api_server=None, method='POST', headers=None, auth=None, timeout=None,
                use_compression=None, jsonify_data=True, want_full_response=False, decode_response_body=True,
                prepend_srv=True, session_handler=None, max_retries=DEFAULT_RETRIES, always_retry=False, files=None,
                **kwargs):
    '''

    :param api_server: API server url, e.g. "http://127.0.0.1:7001"
    :type api_server: string or None
    :param resource: API server route, e.g. "/tasks/list/". If *prepend_srv* is False, a fully qualified URL is expected.
                    If this argument is a callable, it will be called just before each request attempt, and expected to
                    return a tuple (URL, headers). Headers returned by the callback are updated with *headers* (including
                    headers set by this method).
    :type resource: string
    :param data:  Content of the request body
    :type data: list or dict, if *jsonify_data* is True; or string or file-like object, otherwise
    :param method: RESTFUL API methods; POST, PUT, GET, DELETE, default value is POST
    :type method: string
    :param headers: Names and values of HTTP headers to submit with the request
                  (in addition to those needed for authentication, compression,
                  or other options specified with the call).
    :type headers: dict
    :param auth:
    :param timeout: HTTP request timeout, in seconds
    :type timeout: float
    :param use_compression:  "snappy" to use Snappy compression, or None
    :type use_compression: string or None
    :param jsonify_data: If True, *data* is converted from a Python list or dict to a JSON string
    :type jsonify_data: boolean
    :param want_full_response: If True, the full :class:`requests.Response` object is returned
                                (otherwise, only the content of the response body is returned)
    :type want_full_response: boolean
    :param decode_response_body:
    :param prepend_srv: If True, prepends the API server location to the URL
    :type prepend_srv: boolean
    :param session_handler:
    :param max_retries: Maximum number of retries to perform for a request. A "failed" request is retried if any of the following is true:
                        - A response is received from the server, and the content length received does not match the "Content-Length" header.
                        - A response is received from the server, and the response has an HTTP status code in 5xx range.
                        - A response is received from the server, the "Content-Length" header is not set, and the response JSON cannot be parsed.
                        - No response is received from the server, and either *always_retry* is True or the request *method* is "GET".
    :type max_retries: int
    :param always_retry: If True, indicates that it is safe to retry a request on failure
                         - Note: It is not guaranteed that the request will *always* be retried on failure; rather, this is an indication to the function that it would be safe to do so.
    :type always_retry: boolean
    :returns: Response from API server in the format indicated by *want_full_response* and *decode_response_body*.
    :raises: :exc:`requests.exceptions.HTTPError` if an invalid response was received from the server; or :exc:`requests.exceptions.ConnectionError` if a connection cannot be established.

    '''

    if session_handler is None:
        session_handler = SESSION_HANDLERS[os.getpid()]

    if headers is None:
        headers = {}

    url = api_server + resource if prepend_srv else resource

    method = method.upper()

    if jsonify_data:
        data = json.dumps(data)
        if 'Content-Type' not in headers and method == 'POST':
            headers['Content-Type'] = 'application/json'

    if use_compression == 'snappy':
        if not snappy_available:
            raise exceptions.GDError("Snappy compression requested, but the snappy module is unavailable")
        headers['accept-encoding'] = 'snappy'

    last_exc_type, last_error, last_traceback = None, None, None
    time_started = time.time() if timeout else None
    try_index = 0

    while True:

        success, streaming_response_truncated = True, False
        response = None

        try:
            _method, _url, _headers = _process_method_url_headers(method, url, headers)
            _timeout = timeout or 600

            if files:
                if auth:
                    response = session_handler.request(_method, _url, headers=_headers, data=data, timeout=_timeout,
                                                       auth=auth, files=files, **kwargs)
                else:
                    response = session_handler.request(_method, _url, headers=_headers, data=data, timeout=_timeout,
                                                       files=files, **kwargs)
            else:
                if auth:
                    response = session_handler.request(_method, _url, headers=_headers, data=data, timeout=_timeout,
                                                       auth=auth, **kwargs)
                else:
                    response = session_handler.request(_method, _url, headers=_headers, data=data, timeout=_timeout,
                                                       **kwargs)

            # If an HTTP code that is not in the 200 series is received and the content is JSON, parse it and throw the
            # appropriate error.  Otherwise, raise the usual exception.
            if not 200 <= response.status_code < 300:
                # response.headers key lookup is case-insensitive
                if response.headers.get('content-type', '').startswith('application/json'):
                    content = json.loads(response.content.decode('utf-8'))
                    error_class = getattr(exceptions,
                                          # get content["error"]["type"], if it does not exist then return ""
                                          content.get("error", {}).get("type", ""),
                                          exceptions.SGAPIBaseException)
                    raise error_class(content, response.status_code)
                response.raise_for_status()

            if want_full_response:
                return response
            else:
                if 'content-length' in response.headers:
                    if int(response.headers['content-length']) != len(response.content):
                        range_str = (' (%s)' % (headers['Range'],)) if 'Range' in headers else ''
                        raise exceptions.ContentLengthError(
                            "Received response with content-length header set to %s but content length is %d%s" %
                            (response.headers['content-length'], len(response.content), range_str)
                        )
                if use_compression and response.headers.get('content-encoding', '') == 'snappy':
                    # TODO: check if snappy raises any exceptions on truncated response content
                    content = snappy.uncompress(response.content)
                else:
                    content = response.content

                if decode_response_body:
                    content = content.decode('utf-8')
                    if response.headers.get('content-type', '').startswith('application/json'):
                        try:
                            content = json.loads(content)
                            return content
                        except ValueError:
                            # If a streaming API call (no content-length
                            # set) encounters an error it may just halt the
                            # response because it has no other way to
                            # indicate an error. Under these circumstances
                            # the client sees unparseable JSON, and we
                            # should be able to recover.
                            streaming_response_truncated = 'content-length' not in response.headers
                            raise HTTPError("Invalid JSON received from server")

                return content
            raise AssertionError('Should never reach this line: expected a result to have been returned by now')
        except Exception as e:
            success = False
            if timeout and time.time() - time_started > timeout:
                logger.error("{} {}: Timeout exceeded".format(method, url))
            elif isinstance(e, _expected_exceptions):

                last_exc_type, last_error, last_traceback = sys.exc_info()
                exception_msg = traceback.format_exc().splitlines()[-1].strip()

                if response is not None and response.status_code == 503:
                    DEFAULT_RETRY_AFTER_INTERVAL = 10
                    try:
                        seconds_to_wait = int(response.headers.get('retry-after', DEFAULT_RETRY_AFTER_INTERVAL))
                    except ValueError:
                        # retry-after could be formatted as absolute time
                        # instead of seconds to wait. We don't know how to
                        # parse that, but the apiserver doesn't generate
                        # such responses anyway.
                        seconds_to_wait = DEFAULT_RETRY_AFTER_INTERVAL

                    if timeout:
                        time_left = int(max(1, time_started + timeout - time.time()))
                        seconds_to_wait = min(seconds_to_wait, time_left)
                    logger.warn("%s %s: %s. Waiting %d seconds due to server unavailability..."
                                % (method, url, exception_msg, seconds_to_wait))

                    time.sleep(seconds_to_wait)
                    # Note, we escape the "except" block here without
                    # incrementing try_index because 503 responses with
                    # Retry-After should not count against the number of
                    # permitted retries.
                    continue

                # Total number of allowed tries is the initial try + up to
                # (max_retries) subsequent retries.
                total_allowed_tries = max_retries + 1
                # Because try_index is not incremented until we escape this
                # iteration of the loop, try_index is equal to the number of
                # tries that have failed so far, minus one. Test whether we
                # have exhausted all retries.

                if try_index + 1 < total_allowed_tries:
                    if response is None or isinstance(e, exceptions.ContentLengthError) or \
                            streaming_response_truncated:
                        ok_to_retry = always_retry or (method == 'GET') or _is_retryable_exception(e)
                    else:
                        ok_to_retry = 500 <= response.status_code < 600

                    if ok_to_retry:
                        delay = 2 ** try_index
                        logger.warn("%s %s: %s. Waiting %d seconds before retry %d of %d..."
                                    % (method, url, exception_msg, delay, try_index + 1, max_retries))
                        time.sleep(delay)
                        try_index += 1
                        continue

            # All retries have been exhausted OR the error is deemed not
            # retryable. Propagate the latest error back to the caller.
            raise
        finally:
            if success and try_index > 0:
                logger.info("{} {}: Recovered after {} retries".format(method, url, try_index))

        raise AssertionError('Should never reach this line: should have attempted a retry or reraised by now')
    raise AssertionError('Should never reach this line: should never break out of loop')
