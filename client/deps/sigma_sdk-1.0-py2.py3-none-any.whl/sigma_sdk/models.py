# -*- coding=utf-8 -*-

from __future__ import absolute_import, print_function


class SeriesInfo(object):

    def __init__(self, patient_id=None, study_id=None, series_id=None, group_id=None):
        self.patient_id = patient_id
        self.study_id = study_id
        self.series_id = series_id
        self.group_id = group_id


class DataStatus(object):
    NORMAL = "normal"
    UNAVAILABLE = "unavailable"
    UNKNOWN = "unknown"


class AutoRunJobStatus(object):
    FAILED = "failed"
    WAITING = "waiting"
    RUNNING = "running"
    SUCCEED = "succeed"
    UNKNOWN = "unknown"


class FileFormats(object):
    DICOM = "dicom"
    NII = "nii"
    XML = "xml"
    JSON = "json"


class DataInfo(object):

    def __init__(self, patient_id=None, study_id=None, series_id=None, status=None, file_id=None):
        self.patient_id = patient_id
        self.study_id = study_id
        self.series_id = series_id
        self.status = status
        self.file_id = file_id


class JobInfo(object):

    def __init__(self, job_id=None, patient_id=None, study_series_pair=None, status=None, start_ts=None, end_ts=None, priority=None):
        self.job_id = job_id
        self.patient_id = patient_id
        self.study_series_pair = study_series_pair
        self.status = status
        self.start_ts = start_ts
        self.end_ts = end_ts
        self.priority = priority


class AutoRunBaseInfo(object):

    def __init__(self, patient_id=None, study_id=None, series_id=None, accession_number=None, status=AutoRunJobStatus.UNKNOWN):
        self.patient_id = patient_id
        self.study_id = study_id
        self.series_id = series_id
        self.accession_number = accession_number
        self.status = status


class OCRBaseInfo(object):

    def __init__(self, img_file=None, optical_character_value=None):
        self.img_file = img_file
        self.optical_character_value = optical_character_value
